package kr.gagyebu.relay;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private Store store;
    private EditText url, code;
    private RadioButton personB;
    private TextView access, status;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        store = new Store(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        box.setPadding(pad, pad, pad, pad);

        title(box, "가계부 알림 연결");
        note(box, "카드·은행 알림으로 보이는 것만 내 가계부로 보내요. 다른 알림은 이 휴대폰 밖으로 나가지 않아요.");
        note(box, "웹 앱 주소");
        url = field(box, store.url(), InputType.TYPE_TEXT_VARIATION_URI);
        note(box, "가계부 코드");
        code = field(box, store.code(), InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        note(box, "이 휴대폰을 쓰는 사람");
        RadioGroup g = new RadioGroup(this);
        RadioButton a = new RadioButton(this);
        a.setId(1); a.setText("첫 번째 사람 (설정 탭의 왼쪽 이름)");
        personB = new RadioButton(this);
        personB.setId(2); personB.setText("두 번째 사람 (설정 탭의 오른쪽 이름)");
        g.addView(a); g.addView(personB);
        g.check("b".equals(store.who()) ? 2 : 1);
        box.addView(g);
        button(box, "저장", () -> { save(); status.setText("저장했어요"); });
        button(box, "연결 시험", this::test);
        access = note(box, "");
        button(box, "알림 접근 허용 화면 열기", () -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        button(box, "배터리 최적화 예외 화면 열기", () -> startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)));
        status = note(box, "");

        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        setContentView(sv);
    }

    @Override protected void onResume() {
        super.onResume();
        boolean on = String.valueOf(Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners")).contains(getPackageName());
        access.setText(on ? "알림 접근: 허용됨" : "알림 접근: 아직 허용되지 않았어요. 아래 버튼을 눌러 켜 주세요.");
        int waiting = store.queue().length();
        status.setText(store.status() + (waiting > 0 ? "\n보낼 알림 " + waiting + "건 대기 중" : ""));
    }

    private void save() { store.save(url.getText().toString().trim(), code.getText().toString().trim(), personB.isChecked() ? "b" : "a"); }

    private void test() {
        save();
        if (!store.ready()) { status.setText("https로 시작하는 웹 앱 주소와 코드를 입력해 주세요."); return; }
        status.setText("확인하는 중이에요");
        new Thread(() -> {
            String msg;
            try {
                // 금융 내용이 없는 문구라 서버는 코드만 확인하고 저장하지 않는다.
                Http.Result r = Http.post(store.endpoint(System.currentTimeMillis()), Store.body("연결 시험", "연결 시험", "연결 시험"));
                msg = r == Http.Result.DELIVERED ? "연결됐어요" : r == Http.Result.RETRY ? "인터넷 연결이나 웹 앱 주소를 확인해 주세요." : "코드나 배포 권한(모든 사용자)을 확인해 주세요.";
            } catch (Exception e) { msg = "웹 앱 주소를 확인해 주세요."; }
            final String shown = msg;
            runOnUiThread(() -> status.setText(shown));
        }).start();
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }
    private void title(LinearLayout box, String s) { TextView t = new TextView(this); t.setText(s); t.setTextSize(24); box.addView(t); }
    private TextView note(LinearLayout box, String s) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(15); t.setPadding(0, dp(12), 0, dp(2)); box.addView(t); return t;
    }
    private EditText field(LinearLayout box, String v, int variation) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setInputType(InputType.TYPE_CLASS_TEXT | variation); e.setText(v);
        box.addView(e, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)); return e;
    }
    private void button(LinearLayout box, String s, Runnable run) {
        Button b = new Button(this); b.setText(s); b.setOnClickListener(v -> run.run()); box.addView(b);
    }
}
