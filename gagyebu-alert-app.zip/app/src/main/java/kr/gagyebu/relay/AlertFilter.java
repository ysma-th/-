package kr.gagyebu.relay;

import java.util.regex.Pattern;

/** 금융 알림처럼 보이는 것만 통과시킨다. 나머지는 휴대폰 밖으로 나가지 않는다. */
final class AlertFilter {
    private static final Pattern FINANCE = Pattern.compile("은행|뱅크|뱅킹|카드|체크|페이|Pay|토스|Toss|농협|새마을|신협|우체국|SOL|CMS|KB|NH|IBK|신한", Pattern.CASE_INSENSITIVE);
    private static final Pattern AMOUNT = Pattern.compile("\\d[\\d,]*\\s*원|[₩￦]\\s*\\d|(입금|출금|승인|이체)\\s*:?\\s*\\d");
    private static final Pattern ACTION = Pattern.compile("입금|출금|승인|결제|이체");
    private static final Pattern MESSENGER = Pattern.compile("kakao\\.talk|messag|mms|sms", Pattern.CASE_INSENSITIVE);

    private AlertFilter() {}

    static boolean shouldSend(String pkg, String label, String title, String text) {
        String all = label + "\n" + title + "\n" + text;
        if (!FINANCE.matcher(all).find()) return false;
        if (AMOUNT.matcher(all).find()) return true;
        // 메신저와 문자는 금액이 있어야만 보낸다. 개인 대화를 보내지 않기 위해서다.
        if (MESSENGER.matcher(pkg).find()) return false;
        return ACTION.matcher(title + "\n" + text).find();
    }
}
