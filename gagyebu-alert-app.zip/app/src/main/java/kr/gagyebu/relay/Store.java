package kr.gagyebu.relay;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** 설정과 보내지 못한 알림을 이 앱 안에만 보관한다. */
final class Store {
    private static final int MAX_QUEUE = 300;
    private final SharedPreferences p;

    Store(Context c) { p = c.getSharedPreferences("relay", Context.MODE_PRIVATE); }

    String url() { return p.getString("url", ""); }
    String code() { return p.getString("code", ""); }
    String who() { return p.getString("who", "a"); }
    String status() { return p.getString("status", "아직 보낸 알림이 없어요"); }
    boolean ready() { return url().startsWith("https://") && !code().isEmpty(); }

    void save(String url, String code, String who) {
        p.edit().putString("url", url).putString("code", code).putString("who", who).apply();
    }
    void setStatus(String s) { p.edit().putString("status", s).apply(); }

    synchronized void enqueue(String app, String title, String text, long at) {
        JSONArray q = queue();
        try {
            q.put(new JSONObject().put("app", app).put("title", title).put("text", text).put("at", at));
            while (q.length() > MAX_QUEUE) q.remove(0);
            p.edit().putString("queue", q.toString()).apply();
        } catch (JSONException ignored) { }
    }
    synchronized JSONArray queue() {
        try { return new JSONArray(p.getString("queue", "[]")); } catch (JSONException e) { return new JSONArray(); }
    }
    synchronized void removeFirst() {
        JSONArray q = queue();
        if (q.length() > 0) q.remove(0);
        p.edit().putString("queue", q.toString()).apply();
    }

    String endpoint(long at) throws UnsupportedEncodingException {
        return url() + (url().contains("?") ? "&" : "?") + "k=" + URLEncoder.encode(code(), "UTF-8") + "&who=" + who() + "&at=" + at;
    }
    static String body(String app, String title, String text) {
        return "앱: " + oneLine(app) + "\n제목: " + oneLine(title) + "\n내용: " + text;
    }
    private static String oneLine(String s) { return s.replace('\n', ' '); }
}
