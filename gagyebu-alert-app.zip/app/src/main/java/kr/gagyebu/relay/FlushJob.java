package kr.gagyebu.relay;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

/** 인터넷이 될 때 쌓인 알림을 순서대로 보낸다. 실패하면 나중에 다시 시도한다. */
public class FlushJob extends JobService {
    private volatile boolean stopped;

    static void schedule(Context c) {
        JobInfo job = new JobInfo.Builder(1, new ComponentName(c, FlushJob.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setBackoffCriteria(60000, JobInfo.BACKOFF_POLICY_EXPONENTIAL)
                .build();
        JobScheduler js = c.getSystemService(JobScheduler.class);
        // 이미 돌고 있거나 재시도 대기 중이면 그 작업이 새 알림까지 함께 보낸다.
        if (js.getPendingJob(1) == null) js.schedule(job);
    }

    @Override public boolean onStartJob(JobParameters params) {
        stopped = false;
        new Thread(() -> jobFinished(params, flush(new Store(this)))).start();
        return true;
    }

    @Override public boolean onStopJob(JobParameters params) { stopped = true; return true; }

    /** 다시 시도할 필요가 있으면 true */
    private boolean flush(Store s) {
        if (!s.ready()) return false;
        while (!stopped) {
            JSONArray q = s.queue();
            if (q.length() == 0) return false;
            try {
                JSONObject a = q.getJSONObject(0);
                Http.Result r = Http.post(s.endpoint(a.getLong("at")), Store.body(a.getString("app"), a.getString("title"), a.getString("text")));
                if (r == Http.Result.RETRY) { s.setStatus("인터넷이나 서버 문제로 대기 중이에요. 자동으로 다시 보내요."); return true; }
                if (r == Http.Result.REJECTED) { s.setStatus("보내지 못했어요. 웹 앱 주소, 코드, 배포 권한을 확인해 주세요."); return false; }
                s.removeFirst();
                s.setStatus(new SimpleDateFormat("M월 d일 HH:mm", Locale.KOREA).format(new Date()) + " 전송 완료");
            } catch (Exception e) {
                s.removeFirst();
            }
        }
        return true;
    }
}
