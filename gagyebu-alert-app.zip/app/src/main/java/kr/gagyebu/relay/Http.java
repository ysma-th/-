package kr.gagyebu.relay;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Apps Script는 POST를 처리한 뒤 결과 주소로 넘겨 준다(302). */
final class Http {
    enum Result { DELIVERED, RETRY, REJECTED }

    private Http() {}

    static Result post(String url, String body) {
        HttpURLConnection c = null;
        try {
            c = open(url);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "text/plain; charset=utf-8");
            try (OutputStream o = c.getOutputStream()) { o.write(body.getBytes(StandardCharsets.UTF_8)); }
            int code = c.getResponseCode();
            if (code >= 300 && code < 400) {
                String next = c.getHeaderField("Location");
                if (next == null) return Result.DELIVERED;
                try { return interpret(get(next)); } catch (IOException e) { return Result.DELIVERED; }
            }
            if (code >= 200 && code < 300) return interpret(read(c.getInputStream()));
            return code >= 500 ? Result.RETRY : Result.REJECTED;
        } catch (IOException e) {
            return Result.RETRY;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static Result interpret(String reply) { return reply.contains("\"ok\":true") ? Result.DELIVERED : Result.REJECTED; }

    private static String get(String url) throws IOException {
        HttpURLConnection c = open(url);
        try { return read(c.getInputStream()); } finally { c.disconnect(); }
    }

    private static HttpURLConnection open(String url) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setInstanceFollowRedirects(false);
        c.setConnectTimeout(20000);
        c.setReadTimeout(40000);
        return c;
    }

    private static String read(InputStream in) throws IOException {
        try (InputStream i = in) {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = i.read(buf)) > 0) b.write(buf, 0, n);
            return b.toString("UTF-8");
        }
    }
}
