package kr.gagyebu.relay;

import android.app.Notification;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class AlertListener extends NotificationListenerService {
    private static final long REPEAT_MS = 30000;
    private final Map<String, Long> recent = new HashMap<>();

    @Override public void onListenerConnected() { FlushJob.schedule(this); }

    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        Notification n = sbn.getNotification();
        if (n == null || sbn.isOngoing() || getPackageName().equals(sbn.getPackageName())) return;
        if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;
        Bundle e = n.extras;
        if (e == null) return;
        String title = str(e.getCharSequence(Notification.EXTRA_TITLE));
        String text = str(e.getCharSequence(Notification.EXTRA_TEXT));
        String big = str(e.getCharSequence(Notification.EXTRA_BIG_TEXT));
        if (big.length() > text.length()) text = big;
        String label = label(sbn.getPackageName());
        if (!AlertFilter.shouldSend(sbn.getPackageName(), label, title, text) || isRepeat(sbn.getPackageName() + title + text)) return;
        Store s = new Store(this);
        s.enqueue(label, title, text, System.currentTimeMillis());
        FlushJob.schedule(this);
    }

    private synchronized boolean isRepeat(String key) {
        long now = System.currentTimeMillis();
        for (Iterator<Long> it = recent.values().iterator(); it.hasNext();) if (now - it.next() > REPEAT_MS) it.remove();
        return recent.put(key, now) != null;
    }

    private String label(String pkg) {
        try {
            PackageManager pm = getPackageManager();
            ApplicationInfo info = pm.getApplicationInfo(pkg, 0);
            return str(pm.getApplicationLabel(info));
        } catch (PackageManager.NameNotFoundException e) {
            return pkg;
        }
    }

    private static String str(CharSequence c) { return c == null ? "" : c.toString().trim(); }
}
